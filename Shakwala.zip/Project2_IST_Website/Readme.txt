Theme Name: Alstar
Theme URL: https://bootstrapmade.com/alstar-free-parallax-bootstrap-template/
Author: BootstrapMade.com
Author URL: https://bootstrapmade.com

To run this website please start with index.html (as it is the first page) and thereafter the page will be rendered based on the functionality.

All required JS and CSS are inside appropriate folders

URL: https://people.rit.edu/avs2368/Project2/Project2_IST_Website/